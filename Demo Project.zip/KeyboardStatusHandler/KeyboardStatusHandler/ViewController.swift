//
//  ViewController.swift
//  KeyboardStatusHandler
//
//  Created by Alfredo Uzumaki on 5/10/19.
//  Copyright © 2019 Alfredo Uzumaki. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBAction func finishedWritingAction(_ sender: Any) {
        view.endEditing(true)
    }
    
    @IBAction func modalViewButtonAction(_ sender: Any) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        vc.addDismissButton()
        present(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        watchKeyboard() // <= here you call it to work
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopWatchingKeyboard() // <= here you call it to stop working so your class could be deini
    }
    
    func addDismissButton() {
        let button = UIButton(frame: CGRect(x: 10, y: 20, width: 80, height: 40))
        button.setTitle("dismiss", for: .normal)
        button.addTarget(self, action: #selector(dismissAction), for: .touchUpInside)
        view.addSubview(button)
    }
    
    @objc func dismissAction() {
        dismiss(animated: true)
    }
}

